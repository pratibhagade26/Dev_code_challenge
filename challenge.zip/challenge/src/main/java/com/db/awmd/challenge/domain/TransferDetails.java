package com.db.awmd.challenge.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Nonnull;
import java.util.Objects;
/**
 * Immutable transfer details entity with JSON serialization support.
 */
public class TransferDetails {

    /**
     * Details of payer account
     */
    @Nonnull
    private final Account fromAccount;
    /**
     * Details of payee account
     */
    @Nonnull
    private final Account toAccount;

    private TransferDetails(@Nonnull Account fromAccount, @Nonnull Account toAccount) {
        this.fromAccount = Objects.requireNonNull(fromAccount, "fromAccount");
        this.toAccount = Objects.requireNonNull(toAccount, "toAccount");
    }

    @Nonnull
    @JsonProperty("fromAccount")
    public Account getFromAccount() {
        return fromAccount;
    }

    @Nonnull
    @JsonProperty("toAccount")
    public Account getToAccount() {
        return toAccount;
    }

    public static class Builder {

        private Account fromAccount;
        private Account toAccount;

        public Builder setFromAccount(Account fromAccount) {
            this.fromAccount = fromAccount;
            return this;
        }

        public Builder setToAccount(Account toAccount) {
            this.toAccount = toAccount;
            return this;
        }

        public TransferDetails build() {
            return new TransferDetails(fromAccount, toAccount);
        }
    }
}
