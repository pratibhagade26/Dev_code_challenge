package com.db.awmd.challenge.service;

import org.springframework.stereotype.Service;

import com.db.awmd.challenge.domain.TransferDetails;
import com.db.awmd.challenge.domain.TransferRequest;
/**
 * Account transfer service.
 */
@Service
public interface TransferService {

    /**
     * Transfer funds from one account to another
     *
     * @param transferRequest request
     * @return transfer details
     */
    TransferDetails transfer(TransferRequest transferRequest);
}
