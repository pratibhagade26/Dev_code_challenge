package com.db.awmd.challenge.repository;

import java.math.BigDecimal;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.domain.TransferDetails;

public interface AccountsRepository {

  void createAccount(Account account) throws DuplicateAccountIdException;

  Account getAccount(String accountId); /*same*/
  
  Account withdraw(Account account,BigDecimal balance);

  Account deposit(Account account,BigDecimal balance);

  void clearAccounts();

  TransferDetails transferAtomically(String fromId, String toId, BigDecimal amount);

}