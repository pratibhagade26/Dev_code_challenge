package com.db.awmd.challenge.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Immutable transfer request request entity with
 * JSON serialization/deserialization support
 * and request validation support.
 */
@JsonDeserialize(builder = TransferRequest.Builder.class)
public class TransferRequest {

    /**
     * Payer account id
     */
    @NotNull(message = "Payer account id cannot be null")
    private final String fromId;
    /**
     * Payee account id
     */
    @NotNull(message = "Payee account id cannot be null")
    private final String toId;
    /**
     * Transfer amount
     */
    @Min(0)
    private final BigDecimal amount;

    public TransferRequest(String fromId, String toId, BigDecimal amount) {
        this.fromId = fromId;
        this.toId = toId;
        this.amount = amount;
    }

    public String getFromId() {
        return fromId;
    }

    public String getToId() {
        return toId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "TransferRequest{" +
                "fromId=" + fromId +
                ", toId=" + toId +
                ", amount=" + amount +
                '}';
    }

    /**
     * Transfer request builder.
     */
    public static class Builder {
        private String from;
        private String to;
        private BigDecimal amount;

        public Builder withFrom(String from) {
            this.from = from;
            return this;
        }

        public Builder withTo(String to) {
            this.to = to;
            return this;
        }

        public Builder withAmount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        public TransferRequest build() {
            return new TransferRequest(from, to, amount);
        }
    }
}