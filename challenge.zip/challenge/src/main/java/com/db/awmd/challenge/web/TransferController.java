package com.db.awmd.challenge.web;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.db.awmd.challenge.domain.TransferDetails;
import com.db.awmd.challenge.domain.TransferRequest;
import com.db.awmd.challenge.service.TransferService;

import javax.annotation.Nullable;
import javax.validation.Valid;
import com.db.awmd.challenge.domain.Account;
import static com.db.awmd.challenge.web.ErrorsHelper.validate;

/**
 * Transfer operations controller. Returns {@link ResponseEntity} with JSON payload.
 */
@Api("Transfer operations controller")
@RestController
@RequestMapping("/app/api/transfer")
public class TransferController {

    private final TransferService transferService;

    @Autowired
    public TransferController(TransferService transferService) {
        this.transferService = transferService;
    }

    /**
     * Validates request and process transfer.
     *
     * @param request request
     * @param errors  validation errors collector
     * @return result wrapped in ResponseEntity
     */
    @PostMapping("/payment")
    public ResponseEntity<TransferResult> transfer(@RequestBody @Valid TransferRequest request,
                                                   Errors errors) {
        return validate(errors)
                .map(m -> ResponseEntity.badRequest().body(TransferResult.withErrorMessage(m)))
                .orElseGet(() -> {
                    try {
                        TransferDetails transferDetails = transferService.transfer(request);
                        return ResponseEntity.ok(TransferResult.withDetails(transferDetails));
                    } catch (Exception e) {
                        return ResponseEntity.badRequest().body(TransferResult.withErrorMessage(e.getMessage()));
                    }
                });
    }

    /**
     * Support class for JSON serialization.
     */
    private static class TransferResult {

        /**
         * Possible validation error message.
         */
        @Nullable
        private final String errorMessage;
        /**
         * Possible payer account details
         */
        @Nullable
        private final Account fromAccount;
        /**
         * Possible payee account details
         */
        @Nullable
        private final Account toAccount;

        private TransferResult(@Nullable String errorMessage,
                               @Nullable Account fromAccount,
                               @Nullable Account toAccount) {
            this.errorMessage = errorMessage;
            this.fromAccount = fromAccount;
            this.toAccount = toAccount;
        }

        @Nullable
        @JsonProperty("errorMessage")
        public String getErrorMessage() {
            return errorMessage;
        }

        @Nullable
        @JsonProperty("fromAccount")
        public Account getFromAccount() {
            return fromAccount;
        }

        @Nullable
        @JsonProperty("toAccount")
        public Account getToAccount() {
            return toAccount;
        }

        static TransferResult withErrorMessage(String errorMessage) {
            return new TransferResult(errorMessage, null, null);
        }

        static TransferResult withDetails(TransferDetails transferDetails) {
            return new TransferResult(null, transferDetails.getFromAccount(),
                    transferDetails.getToAccount());
        }
    }
}
