package com.db.awmd.challenge.service.impl;

import org.springframework.stereotype.Component;
import com.db.awmd.challenge.domain.TransferDetails;
import com.db.awmd.challenge.domain.TransferRequest;
import com.db.awmd.challenge.service.TransferService;
import com.db.awmd.challenge.repository.AccountsRepository;

/**
 * Funds transfer service using some accounts storage.
 */
/**
 * Funds transfer service using some accounts storage.
 */
@Component
public class TransferServiceImpl implements TransferService {

    private final AccountsRepository accountsRepository;

    public TransferServiceImpl(AccountsRepository accountsRepository) {
        this.accountsRepository = accountsRepository;
    }

    @Override
    public TransferDetails transfer(TransferRequest transferRequest) {
        return accountsRepository.transferAtomically(transferRequest.getFromId(),
                transferRequest.getToId(), transferRequest.getAmount());
    }

}