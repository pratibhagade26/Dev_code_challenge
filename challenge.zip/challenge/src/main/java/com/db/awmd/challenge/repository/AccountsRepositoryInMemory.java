package com.db.awmd.challenge.repository;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.TransferDetails;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import org.springframework.stereotype.Repository;
import lombok.Getter;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {

	private final Map<String, Account> accounts = new ConcurrentHashMap<>();
	
	private final Object lock = new Object();
	
	private static final Logger log = LoggerFactory.getLogger(AccountsRepositoryInMemory.class);
	
	 @Getter
	 Account accountId;
	
	 @Getter
	 Account balance;
	
  @Override
  public void createAccount(Account account) throws DuplicateAccountIdException {
    Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
    if (previousAccount != null) {
      throw new DuplicateAccountIdException(
        "Account id " + account.getAccountId() + " already exists!");
    }
  }

  @Override
  public Account getAccount(String accountId) {
    return accounts.get(accountId);
  }

  @Override
  public void clearAccounts() {
    accounts.clear();
  }
    /**
     * Checks for account presence and balance then atomically replace accounts with new balances.
     * Transfer to the same account is forbidden
     *
     * @param fromId payer account id
     * @param toId   payee account id
     * @param amount amount
     * @return transfer details
     */
    @Override
    public TransferDetails transferAtomically(String fromId, String toId, BigDecimal amount) {
        if (Objects.equals(fromId, toId)) {
            throw new IllegalArgumentException("Accounts should be different");
        }

        if (!accounts.containsKey(fromId)) {
            throw new IllegalArgumentException("Payer account not found");
        }

        if (!accounts.containsKey(toId)) {
            throw new IllegalArgumentException("Payee account not found");
        }

        synchronized (lock) {
            Account fromAcc = accounts.get(fromId);
            Account toAcc = accounts.get(toId);
            log.info("Transfer: thread={}, from={}, to={}, amount={}",
                    Thread.currentThread().getName(), fromAcc, toAcc, amount);

            if (fromAcc.balance.compareTo(amount) < 0) {
                throw new IllegalArgumentException("Insufficient funds");
            }

            accounts.replace(fromId, withdraw(fromAcc, amount));
            accounts.replace(toId, deposit(toAcc,amount));

            return new TransferDetails.Builder()
                    .setFromAccount(new Account(fromId, fromAcc.balance))
                    .setToAccount(new Account(toId, toAcc.balance))
                    .build();
        }
    }


	@Override
	public Account withdraw(Account account ,BigDecimal amount) {
		 return new Account(account.getAccountId(), account.getBalance().subtract(amount));
	}

	@Override
	public Account deposit(Account account, BigDecimal amount) {
		 return new Account(account.getAccountId(),account.getBalance().add(amount));
	}

}